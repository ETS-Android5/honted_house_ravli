package com.pesonal.adsdk.remote;

public interface RewardCallback {

    void onClose(boolean isSuccess);

    void onFail();
}
