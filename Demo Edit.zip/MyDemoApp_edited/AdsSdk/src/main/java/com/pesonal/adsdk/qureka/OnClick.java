package com.pesonal.adsdk.qureka;

public interface OnClick {
    void a();
}