package com.pesonal.adsdk.remote;

public interface InterCallback {
        void onClose();
    }
