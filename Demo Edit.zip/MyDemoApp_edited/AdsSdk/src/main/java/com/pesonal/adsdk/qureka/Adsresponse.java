package com.pesonal.adsdk.qureka;

public class Adsresponse {

    public String f18653a;

    public String f18654b;

    public String f18655c;

    public String f18656d;

    public String f18657e;

    public String f18658f;

    public String f18659g;

    public String f18660h;

    public String banner;
}