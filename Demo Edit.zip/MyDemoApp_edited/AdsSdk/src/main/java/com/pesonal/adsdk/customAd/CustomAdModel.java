package com.pesonal.adsdk.customAd;

public class CustomAdModel {

    int ad_id;
    String app_name;
    String app_packageName;
    String app_logo;
    String app_banner;
    String app_shortDecription;
    String app_rating;
    String app_download;
    String app_AdFormat;

    public int getAd_id() {
        return ad_id;
    }

    public void setAd_id(int ad_id) {
        this.ad_id = ad_id;
    }

    public String getApp_name() {
        return app_name;
    }

    public void setApp_name(String app_name) {
        this.app_name = app_name;
    }

    public String getApp_packageName() {
        return app_packageName;
    }

    public void setApp_packageName(String app_packageName) {
        this.app_packageName = app_packageName;
    }

    public String getApp_logo() {
        return app_logo;
    }

    public void setApp_logo(String app_logo) {
        this.app_logo = app_logo;
    }

    public String getApp_banner() {
        return app_banner;
    }

    public void setApp_banner(String app_banner) {
        this.app_banner = app_banner;
    }

    public String getApp_shortDecription() {
        return app_shortDecription;
    }

    public void setApp_shortDecription(String app_shortDecription) {
        this.app_shortDecription = app_shortDecription;
    }

    public String getApp_rating() {
        return app_rating;
    }

    public void setApp_rating(String app_rating) {
        this.app_rating = app_rating;
    }

    public String getApp_download() {
        return app_download;
    }

    public void setApp_download(String app_download) {
        this.app_download = app_download;
    }

    public String getApp_AdFormat() {
        return app_AdFormat;
    }

    public void setApp_AdFormat(String app_AdFormat) {
        this.app_AdFormat = app_AdFormat;
    }
}
